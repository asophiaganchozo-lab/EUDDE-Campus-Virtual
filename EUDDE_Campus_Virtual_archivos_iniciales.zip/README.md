# EUDDE_Campus Virtual

Versión inicial de demostración del Entorno Virtual de Aprendizaje.

## Archivos
- `index.html`: estructura de la página.
- `style.css`: diseño adaptable celeste y blanco.
- `app.js`: catálogo de 15 asignaturas, 5 módulos por asignatura, avance de demostración y diplomas imprimibles.
- `supabase.sql`: esquema inicial de base de datos para preparar la integración real.

## Cómo probarlo
1. Descarga todos los archivos.
2. Abre `index.html` en un navegador para probar la demostración.
3. Para publicarlo, sube los archivos al repositorio de GitHub y conecta ese repositorio con Vercel.

## Importante
Esta entrega es un prototipo inicial. El ingreso es una simulación local: no crea cuentas reales, no almacena contraseñas y no autentica estudiantes. El progreso de demostración se guarda únicamente en el navegador del dispositivo. Los enlaces de recursos son ejemplos generales y deben revisarse y asignarse a cada materia. Los exámenes, notas oficiales, roles, tareas, notificaciones, recuperación de contraseña y certificados oficiales requieren completar la integración con Supabase y desarrollar sus reglas antes de usarlo con estudiantes reales.

No subir claves privadas, contraseñas ni el archivo `.env` a un repositorio público.
