const subjects = [
  ["Programación y Desarrollo de Software","Especialidad","💻"],
  ["Diseño y Desarrollo Web","Especialidad","🌐"],
  ["Bases de Datos","Especialidad","🗄️"],
  ["Sistemas Operativos","Especialidad","🖥️"],
  ["Redes y Conectividad","Especialidad","📡"],
  ["Soporte Técnico y Mantenimiento","Especialidad","🛠️"],
  ["Aplicaciones Ofimáticas","Especialidad","📊"],
  ["Seguridad Informática","Especialidad","🔐"],
  ["Inteligencia Artificial Aplicada","Especialidad","🤖"],
  ["Ética, Legislación y Ciudadanía Digital","Transversal","⚖️"],
  ["Matemática","Formación general","➗"],
  ["Física","Formación general","⚛️"],
  ["Lengua y Literatura","Formación general","📚"],
  ["Inglés","Formación general","🔤"],
  ["Emprendimiento y Gestión","Formación general","💡"]
];
const moduleTitles = ["Introducción y conceptos básicos","Fundamentos y herramientas","Aplicación práctica","Desarrollo de habilidades","Integración y evaluación final"];
const moduleDescriptions = [
  "Conoce los conceptos principales, la importancia de la asignatura y sus términos básicos.",
  "Identifica los fundamentos, recursos y herramientas que se utilizan en esta área.",
  "Relaciona lo aprendido con ejemplos y situaciones prácticas.",
  "Desarrolla actividades para fortalecer tus conocimientos y habilidades.",
  "Repasa los contenidos, completa la evaluación final y demuestra lo aprendido."
];
const $ = id => document.getElementById(id);
let student = null, activeSubject = null;
const progress = JSON.parse(localStorage.getItem("eudde_progress_demo") || "{}");
function saveProgress(){localStorage.setItem("eudde_progress_demo",JSON.stringify(progress));}
function key(s,m){return `${s}__${m}`;}
function completed(s,m){return !!progress[key(s,m)];}
function renderSubjects(filter=""){
  $("subjectGrid").innerHTML="";
  subjects.forEach(([name,area,icon],i)=>{
    if(!name.toLowerCase().includes(filter.toLowerCase()))return;
    const done=[0,1,2,3,4].filter(m=>completed(i,m)).length;
    const card=document.createElement("article");card.className="subject-card";
    card.innerHTML=`<div class="subject-icon">${icon}</div><h3>${name}</h3><p>${area} · 5 módulos · ${done}/5 completados</p><button type="button">Ver módulos →</button>`;
    card.querySelector("button").addEventListener("click",()=>openSubject(i));
    $("subjectGrid").appendChild(card);
  });
}
function updateStudent(){
  if(!student)return;
  $("studentPanel").classList.remove("hidden");$("logoutBtn").classList.remove("hidden");
  $("studentName").textContent=student.name;
  $("completedCount").textContent=Object.keys(progress).filter(k=>k.endsWith("__true")).length;
}
function openSubject(i){
  if(!student){$("authDialog").showModal();return;}
  activeSubject=i;$("moduleSection").classList.remove("hidden");$("moduleDetail").classList.add("hidden");
  $("subjectTitle").textContent=subjects[i][0];$("subjectArea").textContent=subjects[i][1];
  renderModules();$("moduleSection").scrollIntoView({behavior:"smooth"});
}
function renderModules(){
  const i=activeSubject;let count=[0,1,2,3,4].filter(m=>completed(i,m)).length;
  $("subjectProgress").textContent=`${count} de 5 módulos completados`;
  $("moduleList").innerHTML="";
  for(let m=0;m<5;m++){
    const unlocked=m===0||completed(i,m-1),done=completed(i,m);
    const card=document.createElement("article");card.className="module-card"+(done?" done":"")+(unlocked?"":" locked");
    card.innerHTML=`<span class="number">MÓDULO 0${m+1} ${done?"✓":unlocked?"":"🔒"}</span><h3>${moduleTitles[m]}</h3><p>${done?"Completado":unlocked?"Disponible":"Completa el módulo anterior"}</p><button ${unlocked?"":"disabled"}>${done?"Revisar módulo": "Abrir módulo"}</button>`;
    if(unlocked)card.querySelector("button").addEventListener("click",()=>showModule(m));
    $("moduleList").appendChild(card);
  }
}
function showModule(m){
  const last=m===4,done=completed(activeSubject,m);
  const detail=$("moduleDetail");detail.classList.remove("hidden");
  const resources=[
    ["Repositorio público: MDN Web Docs","https://developer.mozilla.org/es/"],
    ["Repositorio educativo: Khan Academy","https://es.khanacademy.org/"],
    ["Videos educativos: YouTube Educación","https://www.youtube.com/"]
  ];
  detail.innerHTML=`<span class="eyebrow">MÓDULO 0${m+1}</span><h3>${moduleTitles[m]}</h3><p>${moduleDescriptions[m]}</p><h4>Recursos de consulta</h4><div class="resource-list">${resources.map(([t,u])=>`<a href="${u}" target="_blank" rel="noopener">${t} ↗</a>`).join("")}</div><p><strong>Actividad:</strong> revisa al menos un recurso y escribe en tu cuaderno tres ideas importantes relacionadas con ${subjects[activeSubject][0]}.</p>${last?`<h4>Examen final de demostración</h4><p>¿Qué debes hacer para aprender de forma efectiva?</p><label><input type="radio" name="finalQuiz" value="a"> Memorizar sin comprender.</label><br><label><input type="radio" name="finalQuiz" value="b"> Revisar recursos, practicar y comprobar lo aprendido.</label><br><label><input type="radio" name="finalQuiz" value="c"> Saltar todas las actividades.</label><br><button class="btn btn-primary" id="finishBtn">Enviar examen de demostración</button>`:`<button class="btn btn-primary" id="finishBtn">${done?"Módulo completado ✓":"Marcar módulo como completado"}</button>`}`;
  if(!done)$("finishBtn").addEventListener("click",()=>{
    if(last){const answer=document.querySelector('input[name="finalQuiz"]:checked');if(!answer){alert("Selecciona una respuesta para continuar.");return;}if(answer.value!=="b"){alert("Respuesta incorrecta. Revisa los recursos e inténtalo de nuevo.");return;}}
    progress[key(activeSubject,m)]=true;saveProgress();renderModules();updateStudent();showModule(m);
    if(last)showCertificate(subjects[activeSubject][0],true);
    else showCertificate(subjects[activeSubject][0],false,m+1);
  });
  detail.scrollIntoView({behavior:"smooth",block:"nearest"});
}
function showCertificate(subject,final,moduleNo){
  const title=final?"Diploma de conclusión":"Diploma de avance";
  $("certificateContent").innerHTML=`<div class="cert-brand">EUDDE · CAMPUS VIRTUAL</div><h2>${title}</h2><p>Se otorga el presente reconocimiento a</p><div class="recipient">${escapeHtml(student?.name||"Estudiante")}</div><p>Por ${final?"haber completado la ruta de aprendizaje de":"haber avanzado satisfactoriamente en"} la asignatura</p><h3>${subject}</h3>${final?'<div class="grade">Nota de demostración: 10/10</div>':`<p class="grade">Módulo ${moduleNo} de 5 completado</p>`}<p>Fecha: ${new Date().toLocaleDateString("es-EC")}</p><p>Este certificado pertenece a una versión demostrativa del proyecto.</p>`;
  $("certificateDialog").showModal();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
$("authOpenBtn")?.addEventListener("click",()=>$("authDialog").showModal());
$("loginOpenBtn").addEventListener("click",()=>$("authDialog").showModal());
$("startBtn").addEventListener("click",()=>$("asignaturas").scrollIntoView({behavior:"smooth"}));
$("authForm").addEventListener("submit",e=>{e.preventDefault();const name=$("nameInput").value.trim();if(!name)return;student={name};$("authDialog").close();updateStudent();renderSubjects($("searchInput").value);});
$("logoutBtn").addEventListener("click",()=>{student=null;$("studentPanel").classList.add("hidden");$("logoutBtn").classList.add("hidden");$("moduleSection").classList.add("hidden");});
$("searchInput").addEventListener("input",e=>renderSubjects(e.target.value));
$("backBtn").addEventListener("click",()=>$("asignaturas").scrollIntoView({behavior:"smooth"}));
$("closeCertificate").addEventListener("click",()=>$("certificateDialog").close());
$("printCertificate").addEventListener("click",()=>window.print());
renderSubjects();
